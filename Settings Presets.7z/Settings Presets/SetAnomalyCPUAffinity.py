import psutil
import mobase
from typing import List, Union
try:
    from PyQt6.QtGui import QIcon
    from PyQt6.QtWidgets import QWidget, QMessageBox
    # Code specific to MO 2.5.0 and above
except ImportError:
    from PyQt5.QtGui import QIcon
    from PyQt5.QtWidgets import QWidget, QMessageBox
    # Code specific to MO 2.4.4 and below

class AnomalyCPUAffinity(mobase.IPluginTool):

    def __init__(self):
        super().__init__()
        self.__organizer: Union[mobase.IOrganizer, None] = None

    def init(self, organizer: mobase.IOrganizer):
        self.__organizer = organizer
        return True

    def name(self) -> str:
        return "AnomalyCPUAffinity"

    def author(self) -> str:
        return "GaRRuSS"

    def description(self) -> str:
        return "Set optimal CPU affinity for Anomaly.exe"

    def version(self) -> mobase.VersionInfo:
        return mobase.VersionInfo(1, 0, 0, mobase.ReleaseType.FINAL)

    def isActive(self) -> bool:
        return self.__organizer.pluginSetting(self.name(), "enabled") is True

    def settings(self) -> List[mobase.PluginSetting]:
        return [mobase.PluginSetting("enabled", "enable this plugin", True)]

    def displayName(self) -> str:
        return "Anomaly CPU Affinity"

    def tooltip(self) -> str:
        return "Set optimal CPU affinity for Anomaly.exe"

    def icon(self) -> QIcon:
        return QIcon()

    def setParentWidget(self, widget: QWidget) -> None:
        self.__parentWidget = widget


    def display(self) -> None:
        # Specify the name of the target executable
        target_exe = ["AnomalyDX11AVX.exe", "AnomalyDX11.exe", "AnomalyDX10AVX.exe", "AnomalyDX10.exe", "AnomalyDX9AVX.exe", "AnomalyDX9.exe", "AnomalyDX8AVX.exe", "AnomalyDX8.exe"]

        # Determine logical and physical amount of cores
        logical_cores = psutil.cpu_count(logical=True)
        physical_cores = psutil.cpu_count(logical=False)

        # List valible cores depending on cpu type
        if logical_cores == physical_cores:
            available_cores = list(range(1, physical_cores))
        else:
            available_cores = list(range(2, logical_cores - (physical_cores - (logical_cores - physical_cores))))

        # Filter function to search for processes starting with "Anomaly"
        def filter_processes(process):
            return process.name().startswith('Anomaly')

        # Find the process ID (PID) of the target executable starting with "Anomaly"
        for process in filter(filter_processes, psutil.process_iter(['pid', 'name'])):
            # Check if the target executable is among the filtered processes
            if process.name() in target_exe:
                pid = process.pid
                target_exe = process.name()
                # Set the CPU affinity of the process to the available cores
                psutil.Process(pid).cpu_affinity(available_cores)
                #Debug line below
                #QMessageBox.information(self.__parentWidget, "Success", f"Done! CPU affinity of {target_exe} is set correctly.")
                break
        else:
            QMessageBox.information(self.__parentWidget, "Error", "Anomaly is not running!")


def createPlugin() -> mobase.IPlugin:
    return AnomalyCPUAffinity()
